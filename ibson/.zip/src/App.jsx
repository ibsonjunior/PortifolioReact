import './assets/global.css'
import logo from'./assets/ibson.png'
import Contato from './Componentes/Contato/Contato'
import Formulario from './Componentes/Formulario/Formulario'
import Principal from './Componentes/Principal/Principal'
import Sidebar from './Componentes/Sidebar/Sidebar'
import SobreMim from './Componentes/SobreMim/SobreMim'



function App() {

  return (
    <>
      <div className="l-app">

        <div className="navbar">
         <img className="titleHeader" src={logo} alt="Logo"/>
          <Sidebar/>
        </div>
      
        <div className="l-content">

          {/* <!-- Sessão Principal --> */}

          <Principal/>

          {/* <!-- Sessão Sobre mim --> */}


         <SobreMim/>

          {/* <!-- Sessão Contatos--> */}
          <div className="l-page" id="contatos">
            <section>

              <Contato/>

              <Formulario/>

            </section>

            <footer className="u-my-3">
              <span>Todos os direitos reservados fulano.</span>
            </footer>

          </div>

        </div>
      </div>
    </>
  )
}

export default App
