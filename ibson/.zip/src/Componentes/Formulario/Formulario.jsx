import { useState } from "react";
// import { useEffect } from "react";




export default function Formulario(){

    const [form, setForm] = useState({
      name : "",
      email: "",
      subject: ""
    })

    //Verfica os campos estão vázios
    const [emptyValues, setEmptyValues] = useState(false);

    //Valida o form
    const [validEmail, setValidEmail] = useState(false);



//Função para atualizar o valor do form
    const handleChange = (e) => {
      //Nome do campo editado = e.target.name
     
      //Valor do campo enviado = e.target.value
      setValidEmail(true)
      const newProp = form;
      newProp[e.target.name] = e.target.value;
      setForm({ ...newProp })
    }

    //Validação
    const handleSubmit = (e) =>{
      //Não enviar automaticamente 
      e.preventDefault()

      //Verifica se os valores são vázios 
      let emptyValues = Object.values(form).some(obj => obj == "");
      //Se estiver vázio ele vai renderizar uma mensagem de spam
      setEmptyValues(emptyValues)

      //Verificar se o email é válido
      const validEmail = form["email"].toLocaleLowerCase().match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)
      setValidEmail(validEmail)

      if(!emptyValues && validEmail){
        //Posta em algum lugar
        fetch("http://127.0.0.1:5173/", {method: "POST", body: JSON.stringify(form)})

        e.currentTarget.submit()
      }

    }


    return(
      
        <>
        
        <form
            name="contact"
            className="c-form"
            onSubmit={(e) => {handleSubmit(e)}}
            >   
                <div className="c-form__group">
                  <label htmlFor="name" className="c-form__label">Nome</label>
                  {/*onBlur verifica depois que o usuário clica fora do campo  */}
                  <input type="text" placeholder="Digite seu nome" id="name" className="c-form__control" onBlur={(e) => handleChange(e)}   />
                  {/* Se for true, vázio, vai renderizar essa mensagem */}
                  {emptyValues && form["name"] == "" ? <span className="error">O campo precisa ser preencido!</span> : ""}
                </div>
                <div className="c-form__group">
                  <label htmlFor="email" className="c-form__label">E-mail</label>
                  <input type="text" placeholder="Digite seu e-mail" id="email" className="c-form__control" onBlur={(e) => handleChange(e) }/>
                  {/* Se for true, vázio, vai renderizar essa mensagem */}
                  {emptyValues && form["email"] == "" ? <span className="error">O campo Precisa ser preencido!</span> : ""}
                  {!validEmail && form["email"] == "" ?  <span className="error">E-mail inválido</span> : ""}
                </div>
                <div className="c-form__group">
                  <label htmlFor="subject" className="c-form__label">Assunto</label>
                  {/* onChange funciona melhor com modificação em temppo real, verifica enquanto está no campo */}
                  <select id="subject" className="c-form__control" defaultValue={'Qual é o assunto' } onChange={(e) => handleChange(e)}>
                 {/* Se for true, vázio, vai renderizar essa mensagem */}
                 {/* {emptyValues && form["subject"] == "" ? <span className="error">O campo precisa ser preencido!</span> : ""} */}
                 <option value="Qual é o assunto" disabled >Qual é o assunto</option>
                    <option value="orcamento">Orçamento</option>
                    <option value="oportunidade">Oportunidade</option>
                    <option value="parceria">Parcerias</option>
                  </select>
                </div>
                <div className="c-form__group">
                  <label   htmlFor="messager" className="c-form__label">Mensagem</label>
                  <textarea rows="5" placeholder="Se desejar, explique-me melhor..." id="messager" className="c-form__control"></textarea>
                  
                </div>
                <div className="c-form__group">
                  <button className="c-btn" type="submit" >Enviar</button>
                </div>

        </form> 

        </>
    );


// const [corpoFormulario, definirCorporFormulario] = useState({
//   nomeCompleto: null,
//   emailPrincipal: null,
//   subjectAssunto: null,
//   descricao: null
// });

// // ________________________ pegando os valores do formulário e os validando__________________________
// function submeterFormulario(evento){
//   const { nome, email, subject, messager } = evento.target.elements

//   evento.preventDefault()



//   definirCorporFormulario({
//     nomeCompleto: nome.value,
//     emailPrincipal: email.value,
//     subjectAssunto: subject.value,
//     descricao: messager.value 
//   })

//   const nullName = nome.value == ""
//   const nullEmail = email.value == ""
//   const nullSubject = subject.value == 'Qual é o assunto'
//   const nulldescricao = messager.value == ""

 

 
//  if (!nullName && !nullEmail && !nullSubject && !nulldescricao) {
//    alert('OK, já vou lhe retornar, Thanks for the message')
//  }
//  else if (nullEmail && nullName && nullSubject && nulldescricao) {
//   alert('Você está me enviando nada')
// }
//  else if (nullEmail) {
//    alert('Você deve ser velho para não ter email')
//  }
//  else if (nullSubject) {
//    alert('Me fale qual assunto tu quer fala comigo')
//  }
//  else if (nulldescricao) {
//     alert('Você quer falar comigo, mas não disse nada')
//  }
//  else if (nullName) {
//    alert('È SERIO QUE VOCÊ NÃO TEM NOME')
//  }




// }
// // __________________ validando os valores do formulário_____________
// /*useEffect(
// () => {
// console.log('useEffect')

// // aqui é para 

// const {  nomeCompleto,emailPrincipal, subjectAssunto, descricao } = corpoFormulario

// const nullName = nome.value == null
// const nullEmail = email.value == null
// const nullSubject = subject.value == null
// const nulldescricao = messager.value == null




// if (!nullName && !nullEmail && !nullSubject && !nulldescricao) {
// alert('OK, já vou lhe retornar, Thanks for the message')
// }
// else if (nullEmail) {
// alert('Você deve ser velho para não ter email')
// }
// else if (nullSubject) {
// alert('Me fale qual assunto tu quer fala comigo')
// }
// else if (nulldescricao) {
//  alert('Você quer falar comigo, mas não disse nada')
// }
// else if (rightForm) {
//  alert('OK, já vou lhe retornar, Thanks for the message')
// }
// else if (nullName) {
// alert('È SERIO QUE VOCÊ NÃO TEM NOME')
// }
// },
// [corpoFormulario]
// )*/





// return( 

// <>

// <form 
// name="contact" className="c-form" 
// onSubmit={(evento) => submeterFormulario(evento)}
// >

// {/*___________NOME___________ */}
// <div className="c-form__group">
// <label htmlFor="name" className="c-form__label" /*</div>required onBlur={}*/>Nome</label>
// <input 
// type="text" 
// placeholder="Digite seu nome" 
// id="nome" 
// className="c-form__control"
// // required
// ></input>
// </div>

// {/*___________EMAIL___________ */}
// <div className="c-form__group">
// <label htmlFor="email" className="c-form__label">E-mail</label>
// <input 
// type="text" 
// placeholder="Digite seu e-mail" 
// id="email" 
// className="c-form__control"
// // required
// ></input>
// </div>




// {/*___________ASSUNTO___________ */}
// <div className="c-form__group">
// <label htmlFor="subject" className="c-form__label">Assunto</label>
// <select id="subject" className="c-form__control"  defaultValue={'Qual é o assunto' }>
//   <option value="Qual é o assunto" disabled >Qual é o assunto</option>
//   <option value="orcamento">Orçamento</option>
//   <option value="oportunidade">Oportunidade</option>
//   <option value="parceria">Parcerias</option>
// </select>
// </div>

// {/*___________MENSAGEM___________ */}
// <div className="c-form__group">
// <label htmlFor="messager" className="c-form__label">Mensagem</label>
// <textarea rows="5" placeholder="Se desejar, explique-me melhor..." id="messager" className="c-form__control"></textarea>
// </div>

// {/*___________BOTÃO___________ */}
// <div className="c-form__group">
// <button className="c-btn" type='submit'>Enviar</button>
// </div>
// </form>

// {/*?______________Teste para ver se os inputs foram pegos___________ */}
// {/* <div>
// <p>Nome:   {corpoFormulario.nomeCompleto}</p>
// <p>Email:   {corpoFormulario.emailPrincipal}</p>
// <p>Assunto:   {corpoFormulario.subjectAssunto}</p>
// <p>Texto:   {corpoFormulario.descricao}</p>
// </div> */}

// // </>  

// )

 
}