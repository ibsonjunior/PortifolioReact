import { useState } from "react";
import { List } from "phosphor-react";
import { XSquare  } from "phosphor-react";



export default function Sidebar(){

  
    const[sidebarHidden, setSidebarOpen] = useState(false);

    function openMenu(){       
        setSidebarOpen(!sidebarHidden);
    }

   return( 
   
  <div >
    <button onClick={openMenu}  tabIndex={0} className="l-sidebar__btn" >
      <List  size={32} />
    </button>
     

    {sidebarHidden  &&   <div className="l-sidebar"> 
              <button onClick={openMenu}  tabIndex={0} className="l-sidebar__btn" >
                <XSquare  size={32} className="btn_close"/>
              </button>
                 
              <nav className="c-sidebar">
                <a className="c-nav__item" href="#sobre-mim">Sobre mim</a>
                <a className="c-nav__item" href="#contatos">Contatos</a>
              </nav>
            </div> }
               
      </div>
   
  )
}
