
export default function Contato(){
    return(
        <>
        
            <h1 className="title">Posso te ajudar?</h1>

            <nav className="c-nav">
                <a className="c-nav__item" href="">Github</a>
                <a className="c-nav__item" href="">Linkedin</a>
                <a className="c-nav__item" href="tel:+5521972190000">Telefone</a>
            </nav>

        
        </>
    );
}