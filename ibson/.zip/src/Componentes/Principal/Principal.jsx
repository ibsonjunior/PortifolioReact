import boneco from'../Principal/imagem.png'

export default function Principal(){

    return(
        <>

            <div className="bg__profile">
                <main  className="l-page">
                    <h1 className="title">Olá, Ibson Junior</h1>
                    <p className="description">Seja bem vindo ao meu currículo on-line.</p>

                <nav className="c-nav u-my-3">
                    <a className="c-nav__item" href="https://github.com/ibsonjunior" target="_bank">Github</a>
                    <a className="c-nav__item" href="https://www.linkedin.com/in/ibson-jr/" target="_bank">Linkedin</a>
                </nav>

                    <a className="sobre" href="#sobre-mim">sobre mim</a>
                </main>

                <img className="boneco"  src={boneco} alt="Logo"/>
            </div>

        </>
        
    )
}